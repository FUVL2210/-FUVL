#!/system/bin/sh

MODDIR=${0%/*}

MARK_FILE="$MODDIR/已完成首次配置"
ZygiskD="/data/adb/modules/zygisksu/bin/zygiskd"

check_reset_prop() {
	local NAME=$1
	local EXPECTED=$2
	local VALUE=$(resetprop $NAME)
	[ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop -n $NAME $EXPECTED
}
contains_reset_prop() {
	local NAME=$1
	local CONTAINS=$2
	local NEWVAL=$3
	[[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop -n $NAME $NEWVAL
}
resetprop -w sys.boot_completed 0
check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "sys.oem_unlock_allowed" "0"
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

until [ $(getprop sys.boot_completed) -eq 1 ]; do
	sleep 5
done

export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"

crond -c $MODDIR/cron

if [ ! -f "$MARK_FILE" ]; then
	"$ZygiskD" memory-type anonymous
	"$ZygiskD" denylist-policy whitelist
	"$ZygiskD" enforce-denylist just_umount
	"$ZygiskD" linker system
	touch "$MARK_FILE"
fi
