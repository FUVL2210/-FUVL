#!/system/bin/sh

# ========== 全局变量 ==========
MODDIR=${0%/*}
MODULE_DIR="/data/adb/FUVL"
TARGET_DIR="/data/adb/tricky_store"
KEYBOX_URL="https://github.com/FUVL2210/-FUVL/releases/download/g/keybox.xml"
MD5_URL="https://github.com/FUVL2210/-FUVL/releases/download/g/md5.txt"
KEYBOX_PATH="$TARGET_DIR/keybox.xml"
USER_EXCLUSION="$MODULE_DIR/需要取消隐藏BL的用户包名.txt"
SYSTEM_ADDITION="$MODULE_DIR/需要添加的系统应用包名.txt"
TEMP_NEW="$MODULE_DIR/target.txt"
FINAL_TARGET="$TARGET_DIR/target.txt"
TEMP_COMPARE="$MODULE_DIR/target.compare"

mkdir -p "$MODULE_DIR" "$TARGET_DIR"
touch "$USER_EXCLUSION" "$SYSTEM_ADDITION"

if [ -f "$MODDIR/cron/root" ]; then
    echo "当前 Cron 表达式: $(sed -n '1s/sh.*//p' $MODDIR/cron/root)"
    echo
fi

# ========== Keybox 更新函数（带 MD5 预检） ==========
update_keybox() {
    echo "检查 keybox 更新..."
    TEMP_KEYBOX="/data/local/tmp/keybox.xml.tmp"
    TEMP_MD5="/data/local/tmp/md5.txt.tmp"
    mkdir -p /data/local/tmp

    # 获取远程 MD5
    if command -v curl >/dev/null 2>&1; then
        curl -sSL --connect-timeout 5 --max-time 10 -o "$TEMP_MD5" "$MD5_URL"
        ret=$?
    elif command -v wget >/dev/null 2>&1; then
        wget -q --timeout=5 --tries=1 -O "$TEMP_MD5" "$MD5_URL"
        ret=$?
    else
        echo "错误: 未找到 curl 或 wget"
        exit 1
    fi

    if [ $ret -ne 0 ] || [ ! -s "$TEMP_MD5" ]; then
        echo "错误: 无法获取远程 MD5"
        rm -f "$TEMP_MD5"
        exit 1
    fi

    MD5_REMOTE=$(head -n 1 "$TEMP_MD5" | tr -d '[:space:]' | grep -oE '[a-fA-F0-9]{32}' | head -n 1)
    rm -f "$TEMP_MD5"

    if [ -z "$MD5_REMOTE" ]; then
        echo "错误: 远程 MD5 无效"
        exit 1
    fi

    # 检查本地 keybox 是否已是最新
    if [ -f "$KEYBOX_PATH" ]; then
        MD5_LOCAL=$(md5sum "$KEYBOX_PATH" | awk '{print $1}')
        if [ "$MD5_REMOTE" = "$MD5_LOCAL" ]; then
            echo "Keybox 已是最新，无需更新"
            return 0
        fi
    fi

    echo "正在下载 keybox..."
    # 下载 keybox.xml
    if command -v curl >/dev/null 2>&1; then
        curl -sSL --connect-timeout 5 --max-time 10 -o "$TEMP_KEYBOX" "$KEYBOX_URL"
        ret=$?
    else
        wget -q --timeout=5 --tries=1 -O "$TEMP_KEYBOX" "$KEYBOX_URL"
        ret=$?
    fi

    if [ $ret -ne 0 ] || [ ! -s "$TEMP_KEYBOX" ]; then
        echo "错误: keybox 下载失败"
        rm -f "$TEMP_KEYBOX"
        exit 1
    fi

    # 下载后校验 MD5
    MD5_LOCAL_NEW=$(md5sum "$TEMP_KEYBOX" | awk '{print $1}')
    if [ "$MD5_REMOTE" != "$MD5_LOCAL_NEW" ]; then
        echo "错误: 下载后 MD5 校验失败"
        echo "远程 MD5: $MD5_REMOTE"
        echo "本地 MD5: $MD5_LOCAL_NEW"
        rm -f "$TEMP_KEYBOX"
        exit 1
    fi

    mv "$TEMP_KEYBOX" "$KEYBOX_PATH"
    echo "Keybox 更新成功，MD5 校验通过"
}

# ========== 包名列表更新函数（无变动） ==========
update_packages() {
    echo "更新包名列表..."
    rm -f "$TEMP_NEW" "$TEMP_COMPARE"
    {
        echo "android"
        echo "com.google.android.gms"
        echo "com.google.android.gsf"
        echo "com.android.vending"
        echo "com.coloros.sceneservice"
    } > "$TEMP_NEW"
    pm list packages -3 | sed 's/package://g' >> "$TEMP_NEW"
    sort -u "$TEMP_NEW" -o "$TEMP_NEW"

    if [ -s "$USER_EXCLUSION" ]; then
        grep -Fvxf "$USER_EXCLUSION" "$TEMP_NEW" > "$TEMP_COMPARE"
    else
        cp "$TEMP_NEW" "$TEMP_COMPARE"
    fi

    if [ -s "$SYSTEM_ADDITION" ]; then
        cat "$SYSTEM_ADDITION" >> "$TEMP_COMPARE"
        sort -u "$TEMP_COMPARE" -o "$TEMP_COMPARE"
    fi

    if [ -f "$FINAL_TARGET" ]; then
        if cmp -s "$TEMP_COMPARE" "$FINAL_TARGET" 2>/dev/null; then
            echo -e "当前包名列表已是最新\n"
            rm -f "$TEMP_COMPARE"
        else
            mv "$TEMP_COMPARE" "$FINAL_TARGET"
            echo -e "包名列表已更新\n"
        fi
    else
        mv "$TEMP_COMPARE" "$FINAL_TARGET"
        echo -e "配置包名列表完成\n"
    fi
    rm -f "$TEMP_NEW"
}

show_result() {
    echo "Target 列表（前10行）:"
    head -n 10 "$FINAL_TARGET" 2>/dev/null || echo "无"
    echo "取消隐藏的用户包名:"
    [ -s "$USER_EXCLUSION" ] && cat "$USER_EXCLUSION" || echo "无"
    echo "需要隐藏的系统包名:"
    [ -s "$SYSTEM_ADDITION" ] && cat "$SYSTEM_ADDITION" || echo "无"
}

# ========== 主逻辑 ==========
echo "开始一键执行更新..."
update_keybox
update_packages
show_result