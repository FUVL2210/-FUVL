#!/system/bin/sh
MODDIR=${0%/*}

MR="/data/adb/FUVL/"
YH="$MR需要取消隐藏BL的用户包名.txt"
XT="$MR需要添加的系统应用包名.txt"

update() {
    echo "更新包名..."
    sh $MODDIR/FUVL/更新包名.sh
    echo "Target 列表:"
    head -n 10 /data/adb/tricky_store/target.txt
    echo "取消隐藏的用户包名:"
    [ -s "$YH" ] && cat "$YH" || echo "无"
    echo "需要隐藏的系统包名:"
    [ -s "$XT" ] && cat "$XT" || echo "无"
}

echo "更新 Keybox..."
sh $MODDIR/FUVL/更新keybox.sh
update