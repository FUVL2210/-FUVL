#!/system/bin/sh

# 设置权限
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/FUVL 0 0 0755 0755
set_perm $MODPATH/lib/curl 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/keycheck 0 0 0755